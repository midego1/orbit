# Onboarding

- [ ] Laptop
- [x] Badge

| A | B |
| --- | --- |
| 1 | 2 |

Read [Database](./Architecture/Database.md).
