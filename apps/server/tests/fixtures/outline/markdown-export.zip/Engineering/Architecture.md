# Architecture

# Overview

Start with [Onboarding](./Onboarding.md).

 ![Diagram](uploads/u0000000-0000-4000-8000-000000000001/a0000000-0000-4000-8000-000000000001/diagram.png)
